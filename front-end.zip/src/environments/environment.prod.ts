export const environment = {
	production: true,
	apiBase: 'https://bg-moviescollection.herokuapp.com/api',
	moviesEndpoint: '/movies',
	movieCoversEndpoint: '/movies/covers',
};
